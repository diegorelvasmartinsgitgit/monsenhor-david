<?php

class Database {
    private static $host = 'localhost';
    private static $db_name = 'escola_db';
    private static $username = 'root'; 
    private static $password = '';     
    public static $conn;

    public static function getConnection() {
        self::$conn = null;
        try {
            self::$conn = new PDO(
                "mysql:host=" . self::$host . ";dbname=" . self::$db_name . ";charset=utf8",
                self::$username,
                self::$password
            );
            self::$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch(PDOException $exception) {
            echo "Erro de conexão: " . $exception->getMessage();
            exit; 
        }
        return self::$conn;
    }
}


class Professor {
    private $conn;
    private $table_name = "professores";

    public $id;
    public $nome;
    public $email;

    public function __construct() {
        $this->conn = Database::getConnection(); 
    }

    public function save() {
        $query = "INSERT INTO " . $this->table_name . " SET nome=:nome, email=:email";
        $stmt = $this->conn->prepare($query);
        $this->nome = htmlspecialchars(strip_tags($this->nome));
        $this->email = htmlspecialchars(strip_tags($this->email));
        $stmt->bindParam(":nome", $this->nome);
        $stmt->bindParam(":email", $this->email);
        return $stmt->execute();
    }

    public function find($id) {
        $query = "SELECT id, nome, email FROM " . $this->table_name . " WHERE id = ? LIMIT 0,1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            $this->id = $row['id'];
            $this->nome = $row['nome'];
            $this->email = $row['email'];
            return $row;
        }
        return null;
    }

    public function update() {
        $query = "UPDATE " . $this->table_name . " SET nome = :nome, email = :email WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $this->id = htmlspecialchars(strip_tags($this->id));
        $this->nome = htmlspecialchars(strip_tags($this->nome));
        $this->email = htmlspecialchars(strip_tags($this->email));
        $stmt->bindParam(":id", $this->id);
        $stmt->bindParam(":nome", $this->nome);
        $stmt->bindParam(":email", $this->email);
        return $stmt->execute();
    }

    public function delete($id) {
        $query = "DELETE FROM " . $this->table_name . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $id);
        return $stmt->execute();
    }

    public function getAll() {
        $query = "SELECT id, nome, email FROM " . $this->table_name . " ORDER BY nome ASC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }
}


class Turma {
    private $conn;
    private $table_name = "turmas";

    public $id;
    public $nome;
    public $ano;
    public $professor_id; 

    public function __construct() {
        $this->conn = Database::getConnection(); 
    }

    public function save() {
        $query = "INSERT INTO " . $this->table_name . " SET nome=:nome, ano=:ano, professor_id=:professor_id";
        $stmt = $this->conn->prepare($query);
        $this->nome = htmlspecialchars(strip_tags($this->nome));
        $this->ano = htmlspecialchars(strip_tags($this->ano));
        $this->professor_id = htmlspecialchars(strip_tags($this->professor_id));
        $stmt->bindParam(":nome", $this->nome);
        $stmt->bindParam(":ano", $this->ano);
        $stmt->bindParam(":professor_id", $this->professor_id);
        return $stmt->execute();
    }

    public function find($id) {
        $query = "SELECT id, nome, ano, professor_id FROM " . $this->table_name . " WHERE id = ? LIMIT 0,1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            $this->id = $row['id'];
            $this->nome = $row['nome'];
            $this->ano = $row['ano'];
            $this->professor_id = $row['professor_id'];
            return $row;
        }
        return null;
    }

    public function update() {
        $query = "UPDATE " . $this->table_name . " SET nome = :nome, ano = :ano, professor_id = :professor_id WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $this->id = htmlspecialchars(strip_tags($this->id));
        $this->nome = htmlspecialchars(strip_tags($this->nome));
        $this->ano = htmlspecialchars(strip_tags($this->ano));
        $this->professor_id = htmlspecialchars(strip_tags($this->professor_id));
        $stmt->bindParam(":id", $this->id);
        $stmt->bindParam(":nome", $this->nome);
        $stmt->bindParam(":ano", $this->ano);
        $stmt->bindParam(":professor_id", $this->professor_id);
        return $stmt->execute();
    }

    public function delete($id) {
        $query = "DELETE FROM " . $this->table_name . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $id);
        return $stmt->execute();
    }

    public function getAllWithProfessor() {
        $query = "SELECT 
                    t.id, t.nome, t.ano, t.professor_id, p.nome as professor_nome
                  FROM " . $this->table_name . " t
                  LEFT JOIN professores p ON t.professor_id = p.id
                  ORDER BY t.ano, t.nome ASC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }
}


function render_template($title, $content, $message = null) {
    ob_start();
    ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?> | Monsenhor Antônio David </title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap');
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f7f7f7;
        }
    </style>
</head>
<body class="min-h-screen">
    <header class="bg-indigo-600 shadow-md">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <nav class="flex justify-between items-center">
                <a href="escola_completa.php" class="text-2xl font-bold text-white hover:text-indigo-200 transition duration-300">
                    Monsenhor Antônio David 
                </a>
                <div class="space-x-4">
                    <a href="escola_completa.php?action=listar_professores" class="text-white hover:text-indigo-200 transition duration-300 font-medium">Professores</a>
                    <a href="escola_completa.php?action=listar_turmas" class="text-white hover:text-indigo-200 transition duration-300 font-medium">Turmas</a>
                </div>
            </nav>
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <?php if ($message): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-lg relative mb-8" role="alert">
                <strong class="font-bold">Notificação:</strong>
                <span class="block sm:inline"><?= htmlspecialchars(urldecode($message)) ?></span>
            </div>
        <?php endif; ?>
        <?= $content ?>
    </main>
</body>
</html>
    <?php
    echo ob_get_clean();
}


function render_home() {
    ob_start();
    ?>
        <div class="bg-white p-8 rounded-xl shadow-lg text-center">
            <h1 class="text-4xl font-extrabold text-gray-800 mb-6"> Monsenhor Antônio David</h1>
            <p class="text-lg text-gray-600 mb-10">Portal de cadastro de turmas e professores</p>

            <div class="flex flex-col md:flex-row justify-center gap-6">
                
                <a href="escola_completa.php?action=form_professor" class="flex-1 max-w-sm bg-blue-500 hover:bg-blue-600 text-white font-bold py-3 px-6 rounded-lg shadow-md transition duration-300 transform hover:scale-105">
                    <span class="text-xl">➕ Cadastrar Professor</span>
                </a>
                
                <a href="escola_completa.php?action=form_turma" class="flex-1 max-w-sm bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-6 rounded-lg shadow-md transition duration-300 transform hover:scale-105">
                    <span class="text-xl">➕ Cadastrar Turma</span>
                </a>
            </div>
            <div class="mt-6">
                <a href="escola_completa.php?action=listar_professores" class="text-indigo-600 hover:text-indigo-800 font-medium">Ver todos os Professores</a> |
                <a href="escola_completa.php?action=listar_turmas" class="text-indigo-600 hover:text-indigo-800 font-medium">Ver todas as Turmas</a>
            </div>
        </div>
    <?php
    return ob_get_clean();
}

function render_form_professor($professor_data) {
    ob_start();
    $is_editing = !empty($professor_data);
    ?>
    <div class="bg-white p-8 rounded-xl shadow-lg max-w-lg mx-auto">
        <h2 class="text-3xl font-bold text-gray-800 mb-6 text-center">
            <?= $is_editing ? 'Editar Professor' : 'Cadastrar Novo Professor' ?>
        </h2>
        
        <form action="escola_completa.php?action=salvar_professor" method="POST">
            
            <?php if ($is_editing): ?>
                <input type="hidden" name="id" value="<?= htmlspecialchars($professor_data['id']) ?>">
            <?php endif; ?>

            <div class="mb-4">
                <label for="nome" class="block text-gray-700 font-medium mb-2">Nome:</label>
                <input type="text" id="nome" name="nome" required 
                       value="<?= htmlspecialchars($professor_data['nome'] ?? '') ?>"
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-150">
            </div>

            <div class="mb-6">
                <label for="email" class="block text-gray-700 font-medium mb-2">Email:</label>
                <input type="email" id="email" name="email" required 
                       value="<?= htmlspecialchars($professor_data['email'] ?? '') ?>"
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-150">
            </div>

            <button type="submit" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 rounded-lg shadow-md transition duration-300 transform hover:scale-[1.01]">
                <?= $is_editing ? 'Atualizar Professor' : 'Cadastrar Professor' ?>
            </button>
        </form>
    </div>
    <?php
    return ob_get_clean();
}

function render_list_professors($professores) {
    ob_start();
    ?>
    <div class="bg-white p-6 rounded-xl shadow-lg">
        <div class="flex justify-between items-center mb-6">
            <h2 class="text-3xl font-bold text-gray-800">Lista de Professores</h2>
            <a href="escola_completa.php?action=form_professor" class="bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded-lg shadow-md transition duration-300">
                + Novo Professor
            </a>
        </div>

        <?php if (!empty($professores)): ?>
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nome</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                            <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Ações</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php foreach ($professores as $p): ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?= $p['id'] ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><?= htmlspecialchars($p['nome']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><?= htmlspecialchars($p['email']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                <a href="escola_completa.php?action=form_professor&id=<?= $p['id'] ?>" class="text-indigo-600 hover:text-indigo-900 mr-4">Editar</a>
                                <a href="escola_completa.php?action=deletar_professor&id=<?= $p['id'] ?>" 
                                   onclick="return confirm('Tem certeza que deseja excluir o professor <?= htmlspecialchars($p['nome']) ?>?')"
                                   class="text-red-600 hover:text-red-900">Excluir</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p class="text-gray-500">Nenhum professor cadastrado. <a href="escola_completa.php?action=form_professor" class="text-indigo-600 font-medium">Adicionar um agora.</a></p>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}


function render_form_turma($turma_data, $professores_select) {
    ob_start();
    $is_editing = !empty($turma_data);
    $selected_professor_id = $turma_data['professor_id'] ?? null;
    ?>
    <div class="bg-white p-8 rounded-xl shadow-lg max-w-lg mx-auto">
        <h2 class="text-3xl font-bold text-gray-800 mb-6 text-center">
            <?= $is_editing ? 'Editar Turma' : 'Cadastrar Nova Turma' ?>
        </h2>
        
        <form action="escola_completa.php?action=salvar_turma" method="POST">
            
            <?php if ($is_editing): ?>
                <input type="hidden" name="id" value="<?= htmlspecialchars($turma_data['id']) ?>">
            <?php endif; ?>

            <div class="mb-4">
                <label for="nome" class="block text-gray-700 font-medium mb-2">Nome (Ex: 8º Ano B):</label>
                <input type="text" id="nome" name="nome" required 
                       value="<?= htmlspecialchars($turma_data['nome'] ?? '') ?>"
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 transition duration-150">
            </div>

            <div class="mb-4">
                <label for="ano" class="block text-gray-700 font-medium mb-2">Ano (Ex: 2024):</label>
                <input type="number" id="ano" name="ano" required 
                       value="<?= htmlspecialchars($turma_data['ano'] ?? '') ?>"
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 transition duration-150">
            </div>

            <div class="mb-6">
                <label for="professor_id" class="block text-gray-700 font-medium mb-2">Professor Responsável:</label>
                <select id="professor_id" name="professor_id"
                        class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 transition duration-150">
                    
                    <option value="null">-- Selecionar Professor (Opcional, mas recomendado) --</option>
                    
                    <?php 
                    foreach ($professores_select as $p): 
                        $selected = ($p['id'] == $selected_professor_id) ? 'selected' : '';
                    ?>
                        <option value="<?= $p['id'] ?>" <?= $selected ?>>
                            <?= htmlspecialchars($p['nome']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <button type="submit" class="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 rounded-lg shadow-md transition duration-300 transform hover:scale-[1.01]">
                <?= $is_editing ? 'Atualizar Turma' : 'Cadastrar Turma' ?>
            </button>
        </form>
    </div>
    <?php
    return ob_get_clean();
}


function render_list_turmas($turmas) {
    ob_start();
    ?>
    <div class="bg-white p-6 rounded-xl shadow-lg">
        <div class="flex justify-between items-center mb-6">
            <h2 class="text-3xl font-bold text-gray-800">Lista de Turmas</h2>
            <a href="escola_completa.php?action=form_turma" class="bg-green-500 hover:bg-green-600 text-white font-medium py-2 px-4 rounded-lg shadow-md transition duration-300">
                + Nova Turma
            </a>
        </div>

        <?php if (!empty($turmas)): ?>
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nome da Turma</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ano</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Professor Responsável</th>
                            <th scope="col" class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Ações</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php foreach ($turmas as $t): ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?= $t['id'] ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><?= htmlspecialchars($t['nome']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700"><?= htmlspecialchars($t['ano']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                                <?= $t['professor_nome'] ? htmlspecialchars($t['professor_nome']) : 'N/A' ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                <a href="escola_completa.php?action=form_turma&id=<?= $t['id'] ?>" class="text-indigo-600 hover:text-indigo-900 mr-4">Editar</a>
                                <a href="escola_completa.php?action=deletar_turma&id=<?= $t['id'] ?>" 
                                   onclick="return confirm('Tem certeza que deseja excluir a turma <?= htmlspecialchars($t['nome']) ?>?')"
                                   class="text-red-600 hover:text-red-900">Excluir</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p class="text-gray-500">Nenhuma turma cadastrada. <a href="escola_completa.php?action=form_turma" class="text-green-600 font-medium">Adicionar uma agora.</a></p>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}



$action = $_GET['action'] ?? 'home'; 
$id = $_GET['id'] ?? null;
$message = $_GET['message'] ?? null;


$professor_model = new Professor();
$turma_model = new Turma();



if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $redirect_url = null;
    $msg = "Ocorreu um erro desconhecido.";

    if ($action === 'salvar_professor') {
        $professor_model->nome = $_POST['nome'];
        $professor_model->email = $_POST['email'];
        
        if (!empty($_POST['id'])) {
            $professor_model->id = $_POST['id'];
            $success = $professor_model->update();
            $msg = $success ? "Professor atualizado com sucesso!" : "Erro ao atualizar professor.";
        } else {
            $success = $professor_model->save();
            $msg = $success ? "Professor cadastrado com sucesso!" : "Erro ao cadastrar professor (Email duplicado?).";
        }
        $redirect_url = "escola_completa.php?action=listar_professores&message=" . urlencode($msg);

    } elseif ($action === 'salvar_turma') {
        $turma_model->nome = $_POST['nome'];
        $turma_model->ano = $_POST['ano'];
        $turma_model->professor_id = $_POST['professor_id'] === 'null' ? null : $_POST['professor_id']; 

        if (!empty($_POST['id'])) {
            $turma_model->id = $_POST['id'];
            $success = $turma_model->update();
            $msg = $success ? "Turma atualizada com sucesso!" : "Erro ao atualizar turma.";
        } else {
            $success = $turma_model->save();
            $msg = $success ? "Turma cadastrada com sucesso!" : "Erro ao cadastrar turma.";
        }
        $redirect_url = "escola_completa.php?action=listar_turmas&message=" . urlencode($msg);
    }
    
    if ($redirect_url) {
        header("Location: " . $redirect_url);
        exit;
    }
}



$view_content = '';
$title = '';

switch ($action) {
    
    case 'listar_professores':
        $stmt = $professor_model->getAll();
        $professores = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $title = "Professores";
        $view_content = render_list_professors($professores);
        break;

    case 'form_professor':
        $professor_data = null;
        if ($id) {
            $professor_data = $professor_model->find($id);
        }
        $title = $professor_data ? "Editar Professor" : "Novo Professor";
        $view_content = render_form_professor($professor_data);
        break;

    case 'deletar_professor':
        if ($id && $professor_model->delete($id)) {
            $msg = "Professor excluído com sucesso!";
        } else {
            $msg = "Erro ao excluir professor (Pode estar associado a uma Turma).";
        }
        header("Location: escola_completa.php?action=listar_professores&message=" . urlencode($msg));
        exit;

    case 'listar_turmas':
        $stmt = $turma_model->getAllWithProfessor(); 
        $turmas = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $title = "Turmas";
        $view_content = render_list_turmas($turmas);
        break;

    case 'form_turma':
        $turma_data = null;
        if ($id) {
            $turma_data = $turma_model->find($id);
        }
        $stmt_prof = $professor_model->getAll();
        $professores_select = $stmt_prof->fetchAll(PDO::FETCH_ASSOC);

        $title = $turma_data ? "Editar Turma" : "Nova Turma";
        $view_content = render_form_turma($turma_data, $professores_select);
        break;

    case 'deletar_turma':
        if ($id && $turma_model->delete($id)) {
            $msg = "Turma excluída com sucesso!";
        } else {
            $msg = "Erro ao excluir turma.";
        }
        header("Location: escola_completa.php?action=listar_turmas&message=" . urlencode($msg));
        exit;

    case 'home':
    default:
        $title = "Início";
        $view_content = render_home();
        break;
}


render_template($title, $view_content, $message);
?>
